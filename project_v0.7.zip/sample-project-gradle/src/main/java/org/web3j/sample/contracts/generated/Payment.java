package org.web3j.sample.contracts.generated;

import java.math.BigInteger;
import java.util.Arrays;
import java.util.Collections;
import org.web3j.abi.FunctionEncoder;
import org.web3j.abi.TypeReference;
import org.web3j.abi.datatypes.Bool;
import org.web3j.abi.datatypes.Function;
import org.web3j.abi.datatypes.Type;
import org.web3j.crypto.Credentials;
import org.web3j.protocol.Web3j;
import org.web3j.protocol.core.RemoteCall;
import org.web3j.protocol.core.methods.response.TransactionReceipt;
import org.web3j.tx.Contract;
import org.web3j.tx.TransactionManager;

/**
 * <p>Auto generated code.
 * <p><strong>Do not modify!</strong>
 * <p>Please use the <a href="https://docs.web3j.io/command_line.html">web3j command line tools</a>,
 * or the org.web3j.codegen.SolidityFunctionWrapperGenerator in the 
 * <a href="https://github.com/web3j/web3j/tree/master/codegen">codegen module</a> to update.
 *
 * <p>Generated with web3j version 3.5.0.
 */
public class Payment extends Contract {
    private static final String BINARY = "60a06040527344919587108268dba9f26e12899e0893de4c437e608090815261002c9060009060016100d4565b5060408051602081019182905260009081905261004b91600291610139565b5060006003556004805460ff1916600117905560405161061c3881900390819083398101604052805160208083015160018054600160a060020a0319163317905591909201805190926100a391600291850190610139565b506004805460ff19168215151790556100c36401000000006100ca810204565b50506101f4565b6003805434019055565b828054828255906000526020600020908101928215610129579160200282015b828111156101295782518254600160a060020a031916600160a060020a039091161782556020909201916001909101906100f4565b506101359291506101b3565b5090565b828054600181600116156101000203166002900490600052602060002090601f016020900481019282601f1061017a57805160ff19168380011785556101a7565b828001600101855582156101a7579182015b828111156101a757825182559160200191906001019061018c565b506101359291506101da565b6101d791905b80821115610135578054600160a060020a03191681556001016101b9565b90565b6101d791905b8082111561013557600081556001016101e0565b610419806102036000396000f3006080604052600436106100615763ffffffff7c010000000000000000000000000000000000000000000000000000000060003504166331fb67c2811461006657806341c0e1b5146100c157806383ee4089146100d6578063e5c37bf7146100f0575b600080fd5b34801561007257600080fd5b506040805160206004803580820135601f81018490048402850184019095528484526100bf9436949293602493928401919081908401838280828437509497506101199650505050505050565b005b3480156100cd57600080fd5b506100bf610296565b3480156100e257600080fd5b506100bf60043515156102d5565b3480156100fc57600080fd5b5061010561030c565b604080519115158252519081900360200190f35b6000808080805b60005481101561017057600080543391908390811061013b57fe5b60009182526020909120015473ffffffffffffffffffffffffffffffffffffffff16141561016857600191505b600101610120565b81151561017c57600080fd5b60045460ff1615801561021f575060028054604080516020601f6000196101006001871615020190941685900493840181900481028201810190925282815261021f93909290918301828280156102145780601f106101e957610100808354040283529160200191610214565b820191906000526020600020905b8154815290600101906020018083116101f757829003601f168201915b505050505087610315565b1561028e5760005460035481151561023357fe5b3360009081526005602052604081208054939092048381038085019093559750919550935083111561028e57604051339084156108fc029085906000818181858888f1935050505015801561028c573d6000803e3d6000fd5b505b505050505050565b60015473ffffffffffffffffffffffffffffffffffffffff1633146102ba57600080fd5b60015473ffffffffffffffffffffffffffffffffffffffff16ff5b60015473ffffffffffffffffffffffffffffffffffffffff1633146102f957600080fd5b6004805460ff1916911515919091179055565b60045460ff1690565b8051825160009114610329575060006103e7565b816040518082805190602001908083835b602083106103595780518252601f19909201916020918201910161033a565b51815160209384036101000a6000190180199092169116179052604051919093018190038120885190955088945090928392508401908083835b602083106103b25780518252601f199092019160209182019101610393565b6001836020036101000a0380198251168184511680821785525050505050509050019150506040518091039020600019161490505b929150505600a165627a7a7230582028bb32bb9e1ccda9572291b26056406b4541b96c402a63c95810774586f7850e0029";

    public static final String FUNC_WITHDRAW = "withdraw";

    public static final String FUNC_KILL = "kill";

    public static final String FUNC_SETISBLOCKED = "setIsBlocked";

    public static final String FUNC_GETISBLOCKED = "getIsBlocked";

    protected Payment(String contractAddress, Web3j web3j, Credentials credentials, BigInteger gasPrice, BigInteger gasLimit) {
        super(BINARY, contractAddress, web3j, credentials, gasPrice, gasLimit);
    }

    protected Payment(String contractAddress, Web3j web3j, TransactionManager transactionManager, BigInteger gasPrice, BigInteger gasLimit) {
        super(BINARY, contractAddress, web3j, transactionManager, gasPrice, gasLimit);
    }

    public RemoteCall<TransactionReceipt> withdraw(String id) {
        final Function function = new Function(
                FUNC_WITHDRAW, 
                Arrays.<Type>asList(new org.web3j.abi.datatypes.Utf8String(id)), 
                Collections.<TypeReference<?>>emptyList());
        return executeRemoteCallTransaction(function);
    }

    public RemoteCall<TransactionReceipt> kill() {
        final Function function = new Function(
                FUNC_KILL, 
                Arrays.<Type>asList(), 
                Collections.<TypeReference<?>>emptyList());
        return executeRemoteCallTransaction(function);
    }

    public RemoteCall<TransactionReceipt> setIsBlocked(Boolean newState) {
        final Function function = new Function(
                FUNC_SETISBLOCKED, 
                Arrays.<Type>asList(new org.web3j.abi.datatypes.Bool(newState)), 
                Collections.<TypeReference<?>>emptyList());
        return executeRemoteCallTransaction(function);
    }

    public RemoteCall<Boolean> getIsBlocked() {
        final Function function = new Function(FUNC_GETISBLOCKED, 
                Arrays.<Type>asList(), 
                Arrays.<TypeReference<?>>asList(new TypeReference<Bool>() {}));
        return executeRemoteCallSingleValueReturn(function, Boolean.class);
    }

    public static RemoteCall<Payment> deploy(Web3j web3j, Credentials credentials, BigInteger gasPrice, BigInteger gasLimit, BigInteger initialWeiValue, String id, Boolean b) {
        String encodedConstructor = FunctionEncoder.encodeConstructor(Arrays.<Type>asList(new org.web3j.abi.datatypes.Utf8String(id), 
                new org.web3j.abi.datatypes.Bool(b)));
        return deployRemoteCall(Payment.class, web3j, credentials, gasPrice, gasLimit, BINARY, encodedConstructor, initialWeiValue);
    }

    public static RemoteCall<Payment> deploy(Web3j web3j, TransactionManager transactionManager, BigInteger gasPrice, BigInteger gasLimit, BigInteger initialWeiValue, String id, Boolean b) {
        String encodedConstructor = FunctionEncoder.encodeConstructor(Arrays.<Type>asList(new org.web3j.abi.datatypes.Utf8String(id), 
                new org.web3j.abi.datatypes.Bool(b)));
        return deployRemoteCall(Payment.class, web3j, transactionManager, gasPrice, gasLimit, BINARY, encodedConstructor, initialWeiValue);
    }

    public static Payment load(String contractAddress, Web3j web3j, Credentials credentials, BigInteger gasPrice, BigInteger gasLimit) {
        return new Payment(contractAddress, web3j, credentials, gasPrice, gasLimit);
    }

    public static Payment load(String contractAddress, Web3j web3j, TransactionManager transactionManager, BigInteger gasPrice, BigInteger gasLimit) {
        return new Payment(contractAddress, web3j, transactionManager, gasPrice, gasLimit);
    }
}
