/**********************************************************
 *  PACKAGE
 *********************************************************/
package org.web3j.sample;

/**********************************************************
 *  IMPORTS
 *********************************************************/
import java.io.*;
import java.net.*;
import java.util.*;
import javax.xml.parsers.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.w3c.dom.*;

/**********************************************************
 *  CLIENT OF Server-BlockchainManager CONNECTION
 *********************************************************/
class SocketS1 implements Runnable {
	private static final Logger log = LoggerFactory.getLogger(Server.class);
	public final static Object locker1 = new Object();
	
	/*
	 *  METHOD: run
	 *  1. Create client socket in port 5555
	 *  2. Define input/output streams
	 *  3. Send executeWithdraw of operationId
	 *  4. Close descriptors
	*/
    public void run() {
    	boolean executeWithdraw = true;
        Socket sc_manager = null;
        String host_manager = null;
        int port_manager = 0;

        try {
        	// 1. Create client socket in port 5555
            host_manager = "192.168.16.136";
            port_manager = 5555;
            sc_manager = new Socket(host_manager, port_manager);

            // 2. Define input/output streams
            DataOutputStream ostream_manager = new DataOutputStream(sc_manager.getOutputStream());
            
            // 3. Send executeWithdraw of operationId
            synchronized(locker1) {
            	locker1.wait();
	            if(SocketS2.opWithdraw == true) {
	            	ostream_manager.writeBoolean(executeWithdraw);
	            	ostream_manager.flush();
	            	ostream_manager.writeUTF(SocketS2.operationId);
	            	ostream_manager.flush();
	            	log.info("Data for withdrawing sent");
	            }
            }

            // 4. Close descriptors
            sc_manager.close();
            ostream_manager.close();
        }
        
        catch(Exception e) {
            System.err.println("Exception " + e.toString());
            e.printStackTrace();
        }
        
    }
}

/**********************************************************
 *  SERVER OF Server-Client CONNECTION
 *********************************************************/
class SocketS2 implements Runnable {
	private static final Logger log = LoggerFactory.getLogger(Server.class);
	
    private static final String CHAR_LIST = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ1234567890";
    private static final int RANDOM_STRING_LENGTH = 10;
    private static String op = null;
    private static int op1 = 0;
    private static int op2 = 0;
    private static int serverResult = 0;
    public static boolean opWithdraw = false;
    public static String operationId;

    /*
	 *  METHOD: generateRandomString
	 *  1. Generates random strings with chars and numbers
	*/
    public static String generateRandomString() {
        StringBuffer randStr = new StringBuffer();
        for (int i=0; i<RANDOM_STRING_LENGTH; i++) {
            int number = getRandomNumber();
            char ch = CHAR_LIST.charAt(number);
            randStr.append(ch);
        }
        return randStr.toString();
    }

    /*
	 *  METHOD: getRandomNumber
	 *  1. Generates random numbers
	*/
    private static int getRandomNumber() {
        int randomInt = 0;
        Random randomGenerator = new Random();
        randomInt = randomGenerator.nextInt(CHAR_LIST.length());
        if (randomInt-1 == -1) {
            return randomInt;
        } else {
            return randomInt-1;
        }
    }

    /*
	 *  METHOD: readXML
	 *  1. Reads an XML through Java DOM Parser and obtains the values of the task
	*/
    public static void readXML (File myFile) {
        try {
            DocumentBuilderFactory dbFactory = DocumentBuilderFactory.newInstance();
            DocumentBuilder dBuilder = dbFactory.newDocumentBuilder();
            Document doc = dBuilder.parse(myFile);
            doc.getDocumentElement().normalize();

            NodeList nList = doc.getElementsByTagName("task");

            for (int temp = 0; temp<nList.getLength(); temp++) {
                Node nNode = nList.item(temp);
                if (nNode.getNodeType() == Node.ELEMENT_NODE) {
                    Element eElement = (Element) nNode;
                    op1 = Integer.parseInt(eElement.getElementsByTagName("operand1").item(0).getTextContent());
                    op = eElement.getElementsByTagName("operation").item(0).getTextContent();
                    op2 = Integer.parseInt(eElement.getElementsByTagName("operand2").item(0).getTextContent());
                }
            }
        }
        catch(Exception e) {
            System.err.println("Exception " + e.toString());
            e.printStackTrace();
        }
    }
    
    /*
	 *  METHOD: computeOperation
	 *  1. Computes serverResult of client's task
	*/
    public static void computeOperation(int op1, String op, int op2) {
    	if (op.equals("add")) {
            serverResult = op1 + op2;
        }
        else if (op.equals("substract")) {
        	serverResult = op1 - op2;
        }
        else if (op.equals("multiply")) {
        	serverResult = op1 * op2;
        }
        else {
            log.info("Invalid operand");
        }
    }

    /*
	 *  METHOD: run
	 *  1. Create server socket in port 5550
	 *  2. Define input/output streams
	 *  3. Receive xml task 
	 *  4. Generate and send operationId
	 *  5. Compute serverResult
	 *  6. Send serverResult of operationId
	 *  7. Results verification
	 *  	- If success: M3 withdraw
	 *  	- Else: verification failed
	 *  8. Close descriptors
	*/
    public void run() {
        File myFile = new File ("src/main/resources/data2.xml");
        ServerSocket serverAddr_client = null;
        Socket sc_client = null;
        boolean canWithdraw = false;

        try {
        	// 1. Create server socket in port 5550
            serverAddr_client = new ServerSocket(5550);
            while(true) {
                sc_client = serverAddr_client.accept();

                // 2. Define input/output streams
                InputStream in_client = sc_client.getInputStream();
                FileOutputStream out_client = new FileOutputStream(myFile);
                DataOutputStream ostream_client = new DataOutputStream(sc_client.getOutputStream());
                DataInputStream istream_client = new DataInputStream(sc_client.getInputStream());

                // 3. Receive xml task
                byte[] array = new byte[8192];
                int count;

                log.info("Receiving task...");
                while ((count=in_client.read(array)) > 0) {
                    out_client.write(array, 0, count);
                    out_client.flush();
                    break;
                }
                log.info("Task successfully received");

                // 4. Generate and send operationId
                operationId = generateRandomString();
                ostream_client.writeUTF(operationId);
                ostream_client.flush();
                log.info("operationId generated: " + operationId);

                readXML(myFile);
                myFile.delete();

                // 5. Compute serverResult
                log.info("Computing serverResult...");
                computeOperation(op1,op,op2);
                log.info("----------------------------");
                
                // 6. Send serverResult of operationId
                ostream_client.writeUTF(operationId);
                ostream_client.flush();
                ostream_client.writeInt(serverResult);
                ostream_client.flush();
                log.info("serverResult of operation " + operationId + " is " + serverResult);
                log.info("Sending serverResult to Client...");
                log.info("----------------------------");
                
                // 7. Results verification
                canWithdraw = istream_client.readBoolean();
                if(canWithdraw == true) {
                	synchronized(SocketS1.locker1) {
                    	opWithdraw = true;
                    	log.info("I am allowed to withdraw");
        	            SocketS1.locker1.notify();
                	}
                }
                else {
                	log.info("Verification failed, contract killed");
                }
                
                // 8. Close descriptors
                in_client.close();
                out_client.close();
                sc_client.close();
                ostream_client.close();
                istream_client.close();
            }
        }
        
        catch(Exception e) {
            System.err.println("Exception " + e.toString());
            e.printStackTrace();
        }
        
    }
}

/**********************************************************
 *  SERVER 
 *********************************************************/
public class Server {
    public static void main(String[] args) {
        SocketS1 s1 = new SocketS1();
        SocketS2 s2 = new SocketS2();
        Thread t1 = new Thread(s1);
        Thread t2 = new Thread(s2);
        t1.start();
        t2.start();
    }
}
