/**********************************************************
 *  PACKAGE
 *********************************************************/
package org.web3j.sample;

/**********************************************************
 *  IMPORTS
 *********************************************************/
import java.io.*;
import java.net.*;
import java.math.BigInteger;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.web3j.crypto.Credentials;
import org.web3j.crypto.WalletUtils;
import org.web3j.protocol.Web3j;
import org.web3j.protocol.core.DefaultBlockParameterName;
import org.web3j.protocol.core.methods.response.EthGetBalance;
import org.web3j.protocol.http.HttpService;
import org.web3j.sample.contracts.generated.Payment;
import org.web3j.tx.Contract;
import org.web3j.tx.ManagedTransaction;

/**********************************************************
 *  SERVER OF BlockchainManager-Client CONNECTION
 *********************************************************/
class SocketG1 implements Runnable {
	private static final Logger log = LoggerFactory.getLogger(BlockchainManager.class);
	
	/*
	 *  METHOD: run
	 *  1. Create server socket in port 5554
	 *  2. Define input/output streams
	 *  3. Receive smart contract constructor's values: operationId, payment and isBlocked
	 *  4. Create smart contract
	 *  	- Create a new web3j instance to connect to remote nodes on the network
	 *  	- Load wallets
	 *  	- Deploy smart contract
	 *  5. Read new isBlocked value and kill
	 *  	- If isBlocked==false && operationId==SocketG2.operationId && SocketG2.operate==true: successful withdraw
	 *  	- Else: unsuccessful withdraw
	 *  6. Kill contract if verification fail
	 *  7. Execute withdraw if conditions are met
	 *  8. Kill contract
	 *  9. Close descriptors
	*/
	@SuppressWarnings("deprecation")
	public void run() {
		
        ServerSocket serverAddr_client = null;
        Socket sc_client = null;

        try {
        	// 1. Create server socket in port 5554
            serverAddr_client = new ServerSocket(5554);
            while(true) {
                sc_client = serverAddr_client.accept();

                // 2. Define input/output streams
                DataInputStream istream_client = new DataInputStream(sc_client.getInputStream());

                // 3. Receive smart contract constructor's values: operationId, payment and blocked
                String operationId = istream_client.readUTF();
                log.info("Client's operationId: " + operationId);
                long amount = istream_client.readLong();
                log.info("Client's payment: " + amount);
                boolean isBlocked = istream_client.readBoolean();
                log.info("Client's isBlocked: " + isBlocked);
                log.info("Data successfully received, creating smart contract...");
                log.info("----------------------------");

                // 4. Create smart contract
                Web3j web3j = Web3j.build(new HttpService("https://rinkeby.infura.io/v3/6c79a6f86eb44c5199bede769ff22baa"));  
                log.info("Connected to Ethereum client version: " + web3j.web3ClientVersion().send().getWeb3ClientVersion());

                Credentials clientCredentials = WalletUtils.loadCredentials("password","/home/cristuti/.ethereum/testnet/keystore/UTC--2018-08-28T10-13-43.385000000Z--1462b0b3b5e5474d04d6620c2e3dba097b5b790b.json");
                log.info("clientCredentials loaded");
                 
                Credentials serverCredentials = WalletUtils.loadCredentials("password","/home/cristuti/.ethereum/testnet/keystore/UTC--2018-08-28T14-34-29.697000000Z--44919587108268dba9f26e12899e0893de4c437e.json");
                log.info("serverCredentials loaded");

	            EthGetBalance balance1 = web3j.ethGetBalance("0x1462b0b3b5e5474d04d6620c2e3dba097b5b790b", DefaultBlockParameterName.LATEST).sendAsync().get();
	            BigInteger wei1 = balance1.getBalance();
	            log.info("clientBalance 0x1462b0b3b5e5474d04d6620c2e3dba097b5b790b: " + wei1);
	
	            EthGetBalance balance2 = web3j.ethGetBalance("0x44919587108268dba9f26e12899e0893de4c437e", DefaultBlockParameterName.LATEST).sendAsync().get();
	            BigInteger wei2 = balance2.getBalance();
	            log.info("serverBalance 0x44919587108268dba9f26e12899e0893de4c437e: " + wei2);
               
	            BigInteger INITIAL_VALUE = BigInteger.valueOf(amount);

                log.info("Deploying smart contract");
                Payment clientContract = Payment.deploy(
                       web3j, clientCredentials,
                       ManagedTransaction.GAS_PRICE, Contract.GAS_LIMIT, INITIAL_VALUE,
                       operationId, isBlocked).send();

                String contractAddress = clientContract.getContractAddress();
                log.info("Smart contract deployed to address " + contractAddress);
                log.info("View contract at https://rinkeby.etherscan.io/address/" + contractAddress);
       
                EthGetBalance balance3 = web3j.ethGetBalance("0x1462b0b3b5e5474d04d6620c2e3dba097b5b790b", DefaultBlockParameterName.LATEST).sendAsync().get();
	            BigInteger wei3 = balance3.getBalance();
	            log.info("clientBalance 0x1462b0b3b5e5474d04d6620c2e3dba097b5b790b: " + wei3);
	
	            EthGetBalance balance4 = web3j.ethGetBalance("0x44919587108268dba9f26e12899e0893de4c437e", DefaultBlockParameterName.LATEST).sendAsync().get();
	            BigInteger wei4 = balance4.getBalance();
	            log.info("serverBalance 0x44919587108268dba9f26e12899e0893de4c437e: " + wei4);

	            log.info("isBlocked value stored in remote smart contract: " + clientContract.getIsBlocked().send());               
	            log.info("----------------------------");             
		   	       
	            // 5. Read new isBlocked value
	            isBlocked = istream_client.readBoolean();
	            
	            // 6. Kill contract if verification failed
	            if (isBlocked==true) {
	            	clientContract.kill().send();
	 	   	       	log.info("Contract killed");
	            }
	            // 7. Execute withdraw if conditions are met
	            else if (isBlocked==false && operationId.equals(SocketG2.operationId) && SocketG2.operate==true) {
	   	       		log.info("Server allowed to withdraw");	
	   	       		clientContract.setIsBlocked(false).send();
	   	       		log.info("Updated isBlocked value: " + clientContract.getIsBlocked().send());
	   	       		log.info("Withdrawing...");
	   	       		Payment serverContract = Payment.load(contractAddress, web3j, serverCredentials, ManagedTransaction.GAS_PRICE, Contract.GAS_LIMIT);
	   	       		serverContract.withdraw(operationId).send();
	   	       		
	   	       		EthGetBalance balance5 = web3j.ethGetBalance("0x1462b0b3b5e5474d04d6620c2e3dba097b5b790b", DefaultBlockParameterName.LATEST).sendAsync().get();
		            BigInteger wei5 = balance5.getBalance();
		            log.info("clientBalance 0x1462b0b3b5e5474d04d6620c2e3dba097b5b790b: " + wei5);
		
		            EthGetBalance balance6 = web3j.ethGetBalance("0x44919587108268dba9f26e12899e0893de4c437e", DefaultBlockParameterName.LATEST).sendAsync().get();
		            BigInteger wei6 = balance6.getBalance();
		            log.info("serverBalance 0x44919587108268dba9f26e12899e0893de4c437e: " + wei6);
	   	    	   	log.info("Succesful withdrawn of operation " + operationId);
	   	    	   	
	   	    	   	clientContract.kill().send();
	   	    	   	log.info("Contract killed");
               }
	           // 8. Kill contract
	           else {
	        	   	clientContract.kill().send();
	   	    	   	log.info("Contract killed");
	            }
               
	   	       // 9. Close descriptors
               sc_client.close();
               istream_client.close();
             }
         }
        
         catch(Exception e) {
             System.err.println("Exception " + e.toString());
             e.printStackTrace();
         }
        
	}
}

/**********************************************************
 *  SERVER OF BlockchainManager-Server CONNECTION
 *********************************************************/
class SocketG2 implements Runnable {
	//private static final Logger log = LoggerFactory.getLogger(BlockchainManager.class);
	public static boolean operate = false;
	public static String operationId = null;
	 
	/*
	 *  METHOD: run
	 *  1. Create server socket in port 5555
	 *  2. Define input/output streams
	 *  3. Receive executeWithdraw of operationId
	 *  	- If true: M3 withdraw
	 *  	- If 
	 *  4. Close descriptors
	*/
    public void run() {
    	boolean executeWithdraw = false;
        ServerSocket serverAddr_server = null;
        Socket sc_server = null;

        try {
        	// 1. Create server socket in port 5555
        	serverAddr_server = new ServerSocket(5555);
            while(true) {
            	sc_server = serverAddr_server.accept();

            	// 2. Define input/output streams
                DataInputStream istream_server = new DataInputStream(sc_server.getInputStream());

                // 3. Receive executeWithdraw of operationId
                executeWithdraw = istream_server.readBoolean();
                operationId = istream_server.readUTF();
                          
                if(executeWithdraw == true) { 
                	operate = true;          		
            	}
                
                // 4. Close descriptors
                sc_server.close();
                istream_server.close();
            }
        }
        
        catch(Exception e) {
        	System.err.println("Exception " + e.toString());
            e.printStackTrace();
        }
        
    }
}

/**********************************************************
 *  BLOCKCHAINMANAGER
 *********************************************************/
public class BlockchainManager {
	public static void main(String[] args) {
		SocketG1 g1 = new SocketG1();
        SocketG2 g2 = new SocketG2();
        Thread t1 = new Thread(g1);
        Thread t2 = new Thread(g2);
        t1.start();
        t2.start();
    }
}