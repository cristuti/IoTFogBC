/**********************************************************
 *  PACKAGE
 *********************************************************/
package org.web3j.sample;

/**********************************************************
 *  IMPORTS
 *********************************************************/
import java.io.*;
import java.net.*;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

/**********************************************************
 *  CLIENT OF Client-BlockchainManager CONNECTION
 *********************************************************/
class SocketC1 implements Runnable {
	private static final Logger log = LoggerFactory.getLogger(Client.class);
	public final static Object locker1 = new Object();
	public final static Object locker2 = new Object();

	/*
	 *  METHOD: run
	 *  1. Create client socket in port 5554
	 *  2. Define input/output streams
	 *  3. Send smart contract constructor's values: operationId, payment and isBlocked
	 *  4. Send new blocked value
	 *  5. Close descriptors 
	*/
    public void run() {
    	long payment = 50000000000L; //amount in wei
    	Socket sc_manager = null;
        String host_manager = null;
        int port_manager = 0;

        try {
        	// 1. Create client socket in port 5554
            host_manager = "192.168.16.136";
            port_manager = 5554;
            sc_manager = new Socket(host_manager, port_manager);

            // 2. Define input/output streams
            DataOutputStream ostream_manager = new DataOutputStream(sc_manager.getOutputStream());
            
            // 3. Send smart contract constructor's values: operationId, payment and isBlocked
            synchronized(locker1) {
            	locker1.wait();
	            ostream_manager.writeUTF(SocketC2.operationId);
	            ostream_manager.flush();
	            log.info("id sent: " + SocketC2.operationId);
	            ostream_manager.writeLong(payment);
	            ostream_manager.flush();
	            log.info("Payment sent: " + payment);
	            ostream_manager.writeBoolean(SocketC2.isBlocked);
	            ostream_manager.flush();
	            log.info("Blocked sent: " + SocketC2.isBlocked);
	            log.info("Data correctly sent for smart contract generation");
	            log.info("----------------------------");
            }
            
            // 4. Send new blocked value
            synchronized(locker2) {
            	locker2.wait();
	            ostream_manager.writeBoolean(SocketC2.isBlocked);
	            ostream_manager.flush();
	            log.info("Operation unlocked");
	            log.info("----------------------------");    
            }

            // 5. Close descriptors 
            sc_manager.close();
            ostream_manager.close();
        }
        
        catch(Exception e) {
            System.err.println("Exception " + e.toString());
            e.printStackTrace();
        }
        
    }
}

/**********************************************************
 *  CLIENT OF Client-Server CONNECTION
 *********************************************************/
class SocketC2 implements Runnable {
	private static final Logger log = LoggerFactory.getLogger(Client.class);
	private static String op = null;
    private static int op1 = 0;
    private static int op2 = 0;
    private static int clientResult = 0;
    public static String operationId;
    public static boolean isBlocked = true;
    
    /*
	 *  METHOD: readXML
	 *  1. Reads an XML through Java DOM Parser and obtains the values of the task
	*/
    public static void readXML (File myFile) {
    	try {
    		DocumentBuilderFactory dbFactory = DocumentBuilderFactory.newInstance();
            DocumentBuilder dBuilder = dbFactory.newDocumentBuilder();
            Document doc = dBuilder.parse(myFile);
            doc.getDocumentElement().normalize();

            NodeList nList = doc.getElementsByTagName("task");

            for (int temp = 0; temp<nList.getLength(); temp++) {
                Node nNode = nList.item(temp);
                if (nNode.getNodeType() == Node.ELEMENT_NODE) {
                    Element eElement = (Element) nNode;
                    op1 = Integer.parseInt(eElement.getElementsByTagName("operand1").item(0).getTextContent());
                    op = eElement.getElementsByTagName("operation").item(0).getTextContent();
                    op2 = Integer.parseInt(eElement.getElementsByTagName("operand2").item(0).getTextContent());
                }
            }
        }
        catch(Exception e) {
            System.err.println("Exception " + e.toString());
            e.printStackTrace();
        }
    }
    
    /*
	 *  METHOD: verifiyOperation
	 *  1. Verifies serverResult 
	*/
    public static void verifyOperation(int op1, String op, int op2) {
    	if (op.equals("add")) {
    		clientResult = op1 + op2;
        }
        else if (op.equals("substract")) {
        	clientResult = op1 - op2;
        }
        else if (op.equals("multiply")) {
        	clientResult = op1 * op2;
        }
        else {
            log.info("Invalid operand");
        }
    }
	
    /*
	 *  METHOD: run
	 *  1. Create client socket in port 5550
	 *  2. Define input/output streams
	 *  3. Send xml task 
	 *  4. Receive operationId
	 *  5. Receive serverResult of operationId
	 *  6. Compute clientResult
	 *  7. Results verification
	 *  	- If success: M3 unlock withdraw, M2 canWithdraw
	 *  	- Else: verification failed, contract killed
	 *  8. Close descriptors
	*/
    public void run() {
    	ClassLoader classLoader = getClass().getClassLoader();
    	File myFile = new File(classLoader.getResource("data.xml").getFile());
    	int serverResult = 0;
    	boolean canWithdraw = false;
    	
        Socket sc_server = null;
        String host_server = null;
        int port_server = 0;

        try {
        	// 1. Create client socket in port 5550
            host_server = "192.168.16.135";
            port_server = 5550;
            sc_server = new Socket(host_server, port_server);

            // 2. Define input/output streams
            FileInputStream in_server = new FileInputStream(myFile);
            DataInputStream istream_server = new DataInputStream(sc_server.getInputStream());
            DataOutputStream ostream_server = new DataOutputStream(sc_server.getOutputStream());
            OutputStream out_server = sc_server.getOutputStream();
            
            // 3. Send xml task
            byte[] array = new byte[8192];
            int count;
             
            log.info("Sending task to server...");
            while ((count=in_server.read(array)) > 0) {
                out_server.write(array, 0, count);
                out_server.flush();
            }
            log.info("Task successfully sent");
            
            // 4. Receive operationId
            synchronized(SocketC1.locker1) {
	            operationId = istream_server.readUTF();
	            log.info("operationId assigned: " + operationId);
	            log.info("----------------------------");
	            SocketC1.locker1.notify();
            }
            
            // 5. Receive serverResult of operationId
            String id = istream_server.readUTF();
            serverResult = istream_server.readInt();
            log.info("serverResult of operation " + id + " is " + serverResult);
            log.info("Verifying...");
            log.info("----------------------------");
                  
            readXML(myFile);

            // 6. Compute clientResult
            verifyOperation(op1,op,op2);
            
            // 7. Results verification
            if(clientResult == serverResult) {
            	synchronized(SocketC1.locker2) {
                	isBlocked = false;
                    log.info("Verification success, unlocking withdraw...");
    	            SocketC1.locker2.notify();
            	}
            		canWithdraw = true;
    	            ostream_server.writeBoolean(canWithdraw);
    	            ostream_server.flush();
    	            log.info("Server allowed to withdraw"); 
            }
            else {
            	ostream_server.writeBoolean(canWithdraw);
	            ostream_server.flush();
            	log.info("Verification failed, killing contract...");
            }
            
            // 8. Close descriptors
            in_server.close();
            out_server.close();
            sc_server.close();
            istream_server.close();
            ostream_server.close();
        }
        
        catch(Exception e) {
            System.err.println("Exception " + e.toString());
            e.printStackTrace();
        }
        
    }
}

/**********************************************************
 *  CLIENT 
 *********************************************************/
public class Client {
    public static void main(String[] args) {
        SocketC1 c1 = new SocketC1();
        SocketC2 c2 = new SocketC2();
        Thread t1 = new Thread(c1);
        Thread t2 = new Thread(c2);
        t1.start();
        t2.start();
    }
}